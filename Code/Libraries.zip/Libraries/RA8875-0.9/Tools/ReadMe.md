The GenerateFonts tool is built by myself and is used to create the fonts for my custom fork of the RA8875 library. <br>
For a video guild on how to use the GenerateFonts tool vist my youtube page at "Add link here..."

The basic instructions are:
- Choose the font, size and style.
- Click start.
- Click Options and click Auto crop all (this will remove the excess padding around each character and automaticlly update the y position offset of the character.
- Click the close icon (x).
- Your font is located in the fontFiles folder.

You can also edit each character by clicking on the preview on the character.
- Right click is to delete a pixel, avoid using this unless you understand the logic of the tool, in short you should always remove an entire row or column, right clicking a deleted pixel will add it back.
- Left clicking a pixel toogles between a white and balck pixel.
- Click Options save to save your changes to the given character you edited, or just click the close icon (x) to not save the changes.
- You can also auto crop the given character in the editor.
- There is also the option to resize the character, this add a row or column to the character.


Note: The auto cropper works by removing any all white columns or rows until it hits a black pixel in the adjacent row or column.
