
/*******************************************************************************

* name: myriad_pro_small
* family: Myriad Pro
* size: 11
* style: Normal
* --------------------------------------
* included characters:  !"#$%&'()*+,-./0123456789:;<=>?\x0040ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~
* --------------------------------------
* antialiasing: no
* type: proportional
* encoding: latin1
* unicode bom: no
*
* data block size: 8 bit(s), uint8_t
* RLE compression enabled: no
* conversion type: Monochrome, Edge 128
* bits per pixel: 1
*
* preprocess:
*  main scan direction: top_to_bottom
*  line scan direction: forward
*  inverse: yes
* ------------------------------------------------------------------------------
* Created by a custom template of LCD-Image-Converter for .s.u.m.o.t.o.y. RA8875
* Font template version: 2.0
* Note: Font height should be fixed and all glyps must have the same height!
* ------------------------------------------------------------------------------
*******************************************************************************/



#include <stdint.h>



static const uint8_t image_data_myriad_pro_small_0x20[4] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00
};////character: ' '

static const tImage myriad_pro_small_0x20 __PRGMTAG_ = { image_data_myriad_pro_small_0x20,
    2, 4};//character: ' ' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x21[5] __PRGMTAG_  = {
    0x01, 0x24, 0x92, 0x08, 0x00
};////character: '!'

static const tImage myriad_pro_small_0x21 __PRGMTAG_ = { image_data_myriad_pro_small_0x21,
    3, 5};//character: '!' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x22[7] __PRGMTAG_  = {
    0x00, 0x55, 0x50, 0x00, 0x00, 0x00, 0x00
};////character: '"'

static const tImage myriad_pro_small_0x22 __PRGMTAG_ = { image_data_myriad_pro_small_0x22,
    4, 7};//character: '"' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x23[9] __PRGMTAG_  = {
    0x00, 0x00, 0xa5, 0x7d, 0x5f, 0x52, 0x80, 0x00, 0x00
};////character: '#'

static const tImage myriad_pro_small_0x23 __PRGMTAG_ = { image_data_myriad_pro_small_0x23,
    5, 9};//character: '#' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x24[10] __PRGMTAG_  = {
    0x00, 0x02, 0x0e, 0x41, 0x03, 0x02, 0x09, 0xc2, 0x00, 0x00
};////character: '$'

static const tImage myriad_pro_small_0x24 __PRGMTAG_ = { image_data_myriad_pro_small_0x24,
    6, 10};//character: '$' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x25[15] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x0c, 0x49, 0x44, 0xd1, 0xb4, 0x2a, 0x15, 0x11, 0x00, 0x00, 0x00, 0x00
};////character: '%'

static const tImage myriad_pro_small_0x25 __PRGMTAG_ = { image_data_myriad_pro_small_0x25,
    9, 15};//character: '%' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x26[12] __PRGMTAG_  = {
    0x00, 0x00, 0xc2, 0x44, 0x86, 0x34, 0xc6, 0x8c, 0xec, 0x00, 0x00, 0x00
};////character: '&'

static const tImage myriad_pro_small_0x26 __PRGMTAG_ = { image_data_myriad_pro_small_0x26,
    7, 12};//character: '&' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x27[4] __PRGMTAG_  = {
    0x05, 0x40, 0x00, 0x00
};////character: '''

static const tImage myriad_pro_small_0x27 __PRGMTAG_ = { image_data_myriad_pro_small_0x27,
    2, 4};//character: ''' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x28[5] __PRGMTAG_  = {
    0x00, 0x12, 0x92, 0x48, 0x90
};////character: '('

static const tImage myriad_pro_small_0x28 __PRGMTAG_ = { image_data_myriad_pro_small_0x28,
    3, 5};//character: '(' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x29[5] __PRGMTAG_  = {
    0x00, 0x24, 0x49, 0x25, 0x20
};////character: ')'

static const tImage myriad_pro_small_0x29 __PRGMTAG_ = { image_data_myriad_pro_small_0x29,
    3, 5};//character: ')' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x2a[9] __PRGMTAG_  = {
    0x00, 0x10, 0xcf, 0x31, 0x00, 0x00, 0x00, 0x00, 0x00
};////character: '*'

static const tImage myriad_pro_small_0x2a __PRGMTAG_ = { image_data_myriad_pro_small_0x2a,
    5, 9};//character: '*' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x2b[12] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0x02, 0x04, 0x3e, 0x10, 0x20, 0x00, 0x00, 0x00
};////character: '+'

static const tImage myriad_pro_small_0x2b __PRGMTAG_ = { image_data_myriad_pro_small_0x2b,
    7, 12};//character: '+' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x2c[4] __PRGMTAG_  = {
    0x00, 0x00, 0x16, 0x00
};////character: ','

static const tImage myriad_pro_small_0x2c __PRGMTAG_ = { image_data_myriad_pro_small_0x2c,
    2, 4};//character: ',' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x2d[5] __PRGMTAG_  = {
    0x00, 0x00, 0x07, 0x00, 0x00
};////character: '-'

static const tImage myriad_pro_small_0x2d __PRGMTAG_ = { image_data_myriad_pro_small_0x2d,
    3, 5};//character: '-' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x2e[4] __PRGMTAG_  = {
    0x00, 0x00, 0x10, 0x00
};////character: '.'

static const tImage myriad_pro_small_0x2e __PRGMTAG_ = { image_data_myriad_pro_small_0x2e,
    2, 4};//character: '.' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x2f[7] __PRGMTAG_  = {
    0x00, 0x12, 0x22, 0x44, 0x48, 0x00, 0x00
};////character: '/'

static const tImage myriad_pro_small_0x2f __PRGMTAG_ = { image_data_myriad_pro_small_0x2f,
    4, 7};//character: '/' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x30[10] __PRGMTAG_  = {
    0x00, 0x00, 0x1c, 0x8a, 0x28, 0xa2, 0x89, 0xc0, 0x00, 0x00
};////character: '0'

static const tImage myriad_pro_small_0x30 __PRGMTAG_ = { image_data_myriad_pro_small_0x30,
    6, 10};//character: '0' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x31[10] __PRGMTAG_  = {
    0x00, 0x00, 0x0c, 0x50, 0x41, 0x04, 0x10, 0x40, 0x00, 0x00
};////character: '1'

static const tImage myriad_pro_small_0x31 __PRGMTAG_ = { image_data_myriad_pro_small_0x31,
    6, 10};//character: '1' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x32[10] __PRGMTAG_  = {
    0x00, 0x00, 0x1c, 0x08, 0x21, 0x04, 0x21, 0xe0, 0x00, 0x00
};////character: '2'

static const tImage myriad_pro_small_0x32 __PRGMTAG_ = { image_data_myriad_pro_small_0x32,
    6, 10};//character: '2' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x33[10] __PRGMTAG_  = {
    0x00, 0x00, 0x1c, 0x08, 0x23, 0x02, 0x09, 0xc0, 0x00, 0x00
};////character: '3'

static const tImage myriad_pro_small_0x33 __PRGMTAG_ = { image_data_myriad_pro_small_0x33,
    6, 10};//character: '3' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x34[10] __PRGMTAG_  = {
    0x00, 0x00, 0x04, 0x31, 0x49, 0x3e, 0x10, 0x40, 0x00, 0x00
};////character: '4'

static const tImage myriad_pro_small_0x34 __PRGMTAG_ = { image_data_myriad_pro_small_0x34,
    6, 10};//character: '4' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x35[10] __PRGMTAG_  = {
    0x00, 0x00, 0x0e, 0x41, 0xc0, 0x82, 0x09, 0xc0, 0x00, 0x00
};////character: '5'

static const tImage myriad_pro_small_0x35 __PRGMTAG_ = { image_data_myriad_pro_small_0x35,
    6, 10};//character: '5' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x36[10] __PRGMTAG_  = {
    0x00, 0x00, 0x0c, 0x43, 0xc8, 0xa2, 0x89, 0xc0, 0x00, 0x00
};////character: '6'

static const tImage myriad_pro_small_0x36 __PRGMTAG_ = { image_data_myriad_pro_small_0x36,
    6, 10};//character: '6' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x37[10] __PRGMTAG_  = {
    0x00, 0x00, 0x3e, 0x10, 0x42, 0x08, 0x41, 0x00, 0x00, 0x00
};////character: '7'

static const tImage myriad_pro_small_0x37 __PRGMTAG_ = { image_data_myriad_pro_small_0x37,
    6, 10};//character: '7' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x38[10] __PRGMTAG_  = {
    0x00, 0x00, 0x0c, 0x49, 0x27, 0x22, 0x89, 0xc0, 0x00, 0x00
};////character: '8'

static const tImage myriad_pro_small_0x38 __PRGMTAG_ = { image_data_myriad_pro_small_0x38,
    6, 10};//character: '8' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x39[10] __PRGMTAG_  = {
    0x00, 0x00, 0x1c, 0x8a, 0x28, 0x9e, 0x11, 0x80, 0x00, 0x00
};////character: '9'

static const tImage myriad_pro_small_0x39 __PRGMTAG_ = { image_data_myriad_pro_small_0x39,
    6, 10};//character: '9' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x3a[4] __PRGMTAG_  = {
    0x00, 0x10, 0x10, 0x00
};////character: ':'

static const tImage myriad_pro_small_0x3a __PRGMTAG_ = { image_data_myriad_pro_small_0x3a,
    2, 4};//character: ':' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x3b[5] __PRGMTAG_  = {
    0x00, 0x2a, 0x80, 0x00, 0x00
};////character: ';'

static const tImage myriad_pro_small_0x3b __PRGMTAG_ = { image_data_myriad_pro_small_0x3b,
    3, 5};//character: ';' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x3c[12] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00, 0x43, 0x08, 0x30, 0x18, 0x08, 0x00, 0x00, 0x00
};////character: '<'

static const tImage myriad_pro_small_0x3c __PRGMTAG_ = { image_data_myriad_pro_small_0x3c,
    7, 12};//character: '<' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x3d[12] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00, 0x1f, 0x80, 0x00, 0xfc, 0x00, 0x00, 0x00, 0x00
};////character: '='

static const tImage myriad_pro_small_0x3d __PRGMTAG_ = { image_data_myriad_pro_small_0x3d,
    7, 12};//character: '=' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x3e[12] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x0c, 0x06, 0x02, 0x06, 0x30, 0x80, 0x00, 0x00, 0x00
};////character: '>'

static const tImage myriad_pro_small_0x3e __PRGMTAG_ = { image_data_myriad_pro_small_0x3e,
    7, 12};//character: '>' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x3f[7] __PRGMTAG_  = {
    0x00, 0xe1, 0x12, 0x44, 0x04, 0x00, 0x00
};////character: '?'

static const tImage myriad_pro_small_0x3f __PRGMTAG_ = { image_data_myriad_pro_small_0x3f,
    4, 7};//character: '?' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x40[13] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x1c, 0x62, 0x49, 0x95, 0xad, 0x95, 0x42, 0x38, 0x00, 0x00
};////character: '\x0040'

static const tImage myriad_pro_small_0x40 __PRGMTAG_ = { image_data_myriad_pro_small_0x40,
    8, 13};//character: '\x0040' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x41[12] __PRGMTAG_  = {
    0x00, 0x00, 0x81, 0x82, 0x89, 0x12, 0x3c, 0x49, 0x08, 0x00, 0x00, 0x00
};////character: 'A'

static const tImage myriad_pro_small_0x41 __PRGMTAG_ = { image_data_myriad_pro_small_0x41,
    7, 12};//character: 'A' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x42[10] __PRGMTAG_  = {
    0x00, 0x07, 0x12, 0x49, 0x27, 0x91, 0x45, 0xe0, 0x00, 0x00
};////character: 'B'

static const tImage myriad_pro_small_0x42 __PRGMTAG_ = { image_data_myriad_pro_small_0x42,
    6, 10};//character: 'B' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x43[10] __PRGMTAG_  = {
    0x00, 0x03, 0x91, 0x82, 0x08, 0x20, 0x40, 0xf0, 0x00, 0x00
};////character: 'C'

static const tImage myriad_pro_small_0x43 __PRGMTAG_ = { image_data_myriad_pro_small_0x43,
    6, 10};//character: 'C' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x44[12] __PRGMTAG_  = {
    0x00, 0x01, 0xe2, 0x24, 0x28, 0x50, 0xa1, 0x44, 0xf0, 0x00, 0x00, 0x00
};////character: 'D'

static const tImage myriad_pro_small_0x44 __PRGMTAG_ = { image_data_myriad_pro_small_0x44,
    7, 12};//character: 'D' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x45[9] __PRGMTAG_  = {
    0x00, 0x1e, 0x84, 0x21, 0xe8, 0x43, 0xc0, 0x00, 0x00
};////character: 'E'

static const tImage myriad_pro_small_0x45 __PRGMTAG_ = { image_data_myriad_pro_small_0x45,
    5, 9};//character: 'E' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x46[9] __PRGMTAG_  = {
    0x00, 0x1e, 0x84, 0x21, 0xe8, 0x42, 0x00, 0x00, 0x00
};////character: 'F'

static const tImage myriad_pro_small_0x46 __PRGMTAG_ = { image_data_myriad_pro_small_0x46,
    5, 9};//character: 'F' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x47[12] __PRGMTAG_  = {
    0x00, 0x00, 0x73, 0x18, 0x10, 0x23, 0xc1, 0x42, 0x78, 0x00, 0x00, 0x00
};////character: 'G'

static const tImage myriad_pro_small_0x47 __PRGMTAG_ = { image_data_myriad_pro_small_0x47,
    7, 12};//character: 'G' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x48[12] __PRGMTAG_  = {
    0x00, 0x01, 0x12, 0x24, 0x48, 0x9f, 0x22, 0x44, 0x88, 0x00, 0x00, 0x00
};////character: 'H'

static const tImage myriad_pro_small_0x48 __PRGMTAG_ = { image_data_myriad_pro_small_0x48,
    7, 12};//character: 'H' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x49[5] __PRGMTAG_  = {
    0x01, 0x24, 0x92, 0x48, 0x00
};////character: 'I'

static const tImage myriad_pro_small_0x49 __PRGMTAG_ = { image_data_myriad_pro_small_0x49,
    3, 5};//character: 'I' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x4a[7] __PRGMTAG_  = {
    0x00, 0x22, 0x22, 0x22, 0x2c, 0x00, 0x00
};////character: 'J'

static const tImage myriad_pro_small_0x4a __PRGMTAG_ = { image_data_myriad_pro_small_0x4a,
    4, 7};//character: 'J' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x4b[10] __PRGMTAG_  = {
    0x00, 0x04, 0x52, 0x51, 0x85, 0x12, 0x49, 0x10, 0x00, 0x00
};////character: 'K'

static const tImage myriad_pro_small_0x4b __PRGMTAG_ = { image_data_myriad_pro_small_0x4b,
    6, 10};//character: 'K' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x4c[9] __PRGMTAG_  = {
    0x00, 0x10, 0x84, 0x21, 0x08, 0x43, 0xc0, 0x00, 0x00
};////character: 'L'

static const tImage myriad_pro_small_0x4c __PRGMTAG_ = { image_data_myriad_pro_small_0x4c,
    5, 9};//character: 'L' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x4d[15] __PRGMTAG_  = {
    0x00, 0x00, 0x10, 0x98, 0x6a, 0x55, 0x2a, 0x95, 0x2a, 0x99, 0x48, 0x80, 0x00, 0x00, 0x00
};////character: 'M'

static const tImage myriad_pro_small_0x4d __PRGMTAG_ = { image_data_myriad_pro_small_0x4d,
    9, 15};//character: 'M' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x4e[12] __PRGMTAG_  = {
    0x00, 0x01, 0x13, 0x25, 0x4a, 0x95, 0x2a, 0x4c, 0x88, 0x00, 0x00, 0x00
};////character: 'N'

static const tImage myriad_pro_small_0x4e __PRGMTAG_ = { image_data_myriad_pro_small_0x4e,
    7, 12};//character: 'N' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x4f[13] __PRGMTAG_  = {
    0x00, 0x00, 0x38, 0x44, 0x82, 0x82, 0x82, 0x82, 0x44, 0x38, 0x00, 0x00, 0x00
};////character: 'O'

static const tImage myriad_pro_small_0x4f __PRGMTAG_ = { image_data_myriad_pro_small_0x4f,
    8, 13};//character: 'O' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x50[10] __PRGMTAG_  = {
    0x00, 0x07, 0x12, 0x49, 0x27, 0x10, 0x41, 0x00, 0x00, 0x00
};////character: 'P'

static const tImage myriad_pro_small_0x50 __PRGMTAG_ = { image_data_myriad_pro_small_0x50,
    6, 10};//character: 'P' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x51[13] __PRGMTAG_  = {
    0x00, 0x00, 0x38, 0x44, 0x82, 0x82, 0x82, 0x82, 0x44, 0x38, 0x06, 0x00, 0x00
};////character: 'Q'

static const tImage myriad_pro_small_0x51 __PRGMTAG_ = { image_data_myriad_pro_small_0x51,
    8, 13};//character: 'Q' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x52[10] __PRGMTAG_  = {
    0x00, 0x07, 0x12, 0x49, 0x27, 0x14, 0x49, 0x20, 0x00, 0x00
};////character: 'R'

static const tImage myriad_pro_small_0x52 __PRGMTAG_ = { image_data_myriad_pro_small_0x52,
    6, 10};//character: 'R' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x53[9] __PRGMTAG_  = {
    0x00, 0x0c, 0x94, 0x10, 0x41, 0x0b, 0x80, 0x00, 0x00
};////character: 'S'

static const tImage myriad_pro_small_0x53 __PRGMTAG_ = { image_data_myriad_pro_small_0x53,
    5, 9};//character: 'S' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x54[9] __PRGMTAG_  = {
    0x00, 0x3e, 0x42, 0x10, 0x84, 0x21, 0x00, 0x00, 0x00
};////character: 'T'

static const tImage myriad_pro_small_0x54 __PRGMTAG_ = { image_data_myriad_pro_small_0x54,
    5, 9};//character: 'T' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x55[12] __PRGMTAG_  = {
    0x00, 0x01, 0x12, 0x24, 0x48, 0x91, 0x22, 0x44, 0x70, 0x00, 0x00, 0x00
};////character: 'U'

static const tImage myriad_pro_small_0x55 __PRGMTAG_ = { image_data_myriad_pro_small_0x55,
    7, 12};//character: 'U' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x56[10] __PRGMTAG_  = {
    0x00, 0x08, 0x62, 0x49, 0x24, 0x8a, 0x30, 0x80, 0x00, 0x00
};////character: 'V'

static const tImage myriad_pro_small_0x56 __PRGMTAG_ = { image_data_myriad_pro_small_0x56,
    6, 10};//character: 'V' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x57[15] __PRGMTAG_  = {
    0x00, 0x00, 0x22, 0x31, 0x15, 0x52, 0xa9, 0x54, 0xaa, 0x66, 0x11, 0x00, 0x00, 0x00, 0x00
};////character: 'W'

static const tImage myriad_pro_small_0x57 __PRGMTAG_ = { image_data_myriad_pro_small_0x57,
    9, 15};//character: 'W' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x58[10] __PRGMTAG_  = {
    0x00, 0x0c, 0x52, 0x30, 0x83, 0x0c, 0x4a, 0x10, 0x00, 0x00
};////character: 'X'

static const tImage myriad_pro_small_0x58 __PRGMTAG_ = { image_data_myriad_pro_small_0x58,
    6, 10};//character: 'X' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x59[10] __PRGMTAG_  = {
    0x00, 0x08, 0xa2, 0x51, 0x42, 0x08, 0x20, 0x80, 0x00, 0x00
};////character: 'Y'

static const tImage myriad_pro_small_0x59 __PRGMTAG_ = { image_data_myriad_pro_small_0x59,
    6, 10};//character: 'Y' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x5a[10] __PRGMTAG_  = {
    0x00, 0x07, 0xc2, 0x08, 0x41, 0x08, 0x21, 0xf0, 0x00, 0x00
};////character: 'Z'

static const tImage myriad_pro_small_0x5a __PRGMTAG_ = { image_data_myriad_pro_small_0x5a,
    6, 10};//character: 'Z' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x5b[5] __PRGMTAG_  = {
    0x01, 0xa4, 0x92, 0x49, 0x30
};////character: '['

static const tImage myriad_pro_small_0x5b __PRGMTAG_ = { image_data_myriad_pro_small_0x5b,
    3, 5};//character: '[' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x5c[7] __PRGMTAG_  = {
    0x00, 0x84, 0x44, 0x22, 0x21, 0x00, 0x00
};////character: '\'

static const tImage myriad_pro_small_0x5c __PRGMTAG_ = { image_data_myriad_pro_small_0x5c,
    4, 7};//character: '\' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x5d[5] __PRGMTAG_  = {
    0x03, 0x24, 0x92, 0x49, 0x60
};////character: ']'

static const tImage myriad_pro_small_0x5d __PRGMTAG_ = { image_data_myriad_pro_small_0x5d,
    3, 5};//character: ']' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x5e[12] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x82, 0x85, 0x0a, 0x22, 0x00, 0x00, 0x00, 0x00, 0x00
};////character: '^'

static const tImage myriad_pro_small_0x5e __PRGMTAG_ = { image_data_myriad_pro_small_0x5e,
    7, 12};//character: '^' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x5f[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3f, 0x00
};////character: '_'

static const tImage myriad_pro_small_0x5f __PRGMTAG_ = { image_data_myriad_pro_small_0x5f,
    6, 10};//character: '_' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x60[5] __PRGMTAG_  = {
    0x02, 0x20, 0x00, 0x00, 0x00
};////character: '`'

static const tImage myriad_pro_small_0x60 __PRGMTAG_ = { image_data_myriad_pro_small_0x60,
    3, 5};//character: '`' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x61[9] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x79, 0xf1, 0x9b, 0x40, 0x00, 0x00
};////character: 'a'

static const tImage myriad_pro_small_0x61 __PRGMTAG_ = { image_data_myriad_pro_small_0x61,
    5, 9};//character: 'a' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x62[10] __PRGMTAG_  = {
    0x00, 0x04, 0x10, 0x41, 0xe4, 0x51, 0x45, 0xe0, 0x00, 0x00
};////character: 'b'

static const tImage myriad_pro_small_0x62 __PRGMTAG_ = { image_data_myriad_pro_small_0x62,
    6, 10};//character: 'b' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x63[9] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x3a, 0x10, 0x83, 0x80, 0x00, 0x00
};////character: 'c'

static const tImage myriad_pro_small_0x63 __PRGMTAG_ = { image_data_myriad_pro_small_0x63,
    5, 9};//character: 'c' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x64[10] __PRGMTAG_  = {
    0x00, 0x00, 0x82, 0x09, 0xe8, 0xa2, 0x89, 0xe0, 0x00, 0x00
};////character: 'd'

static const tImage myriad_pro_small_0x64 __PRGMTAG_ = { image_data_myriad_pro_small_0x64,
    6, 10};//character: 'd' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x65[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0xc8, 0xbe, 0x81, 0xe0, 0x00, 0x00
};////character: 'e'

static const tImage myriad_pro_small_0x65 __PRGMTAG_ = { image_data_myriad_pro_small_0x65,
    6, 10};//character: 'e' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x66[7] __PRGMTAG_  = {
    0x00, 0x34, 0x4e, 0x44, 0x44, 0x00, 0x00
};////character: 'f'

static const tImage myriad_pro_small_0x66 __PRGMTAG_ = { image_data_myriad_pro_small_0x66,
    4, 7};//character: 'f' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x67[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0xe8, 0xa2, 0x89, 0xe0, 0xbc, 0x00
};////character: 'g'

static const tImage myriad_pro_small_0x67 __PRGMTAG_ = { image_data_myriad_pro_small_0x67,
    6, 10};//character: 'g' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x68[10] __PRGMTAG_  = {
    0x00, 0x04, 0x10, 0x41, 0xc4, 0x92, 0x49, 0x20, 0x00, 0x00
};////character: 'h'

static const tImage myriad_pro_small_0x68 __PRGMTAG_ = { image_data_myriad_pro_small_0x68,
    6, 10};//character: 'h' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x69[5] __PRGMTAG_  = {
    0x01, 0x00, 0x92, 0x48, 0x00
};////character: 'i'

static const tImage myriad_pro_small_0x69 __PRGMTAG_ = { image_data_myriad_pro_small_0x69,
    3, 5};//character: 'i' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x6a[5] __PRGMTAG_  = {
    0x01, 0x00, 0x92, 0x49, 0x40
};////character: 'j'

static const tImage myriad_pro_small_0x6a __PRGMTAG_ = { image_data_myriad_pro_small_0x6a,
    3, 5};//character: 'j' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x6b[9] __PRGMTAG_  = {
    0x00, 0x10, 0x84, 0x25, 0x4c, 0x52, 0x40, 0x00, 0x00
};////character: 'k'

static const tImage myriad_pro_small_0x6b __PRGMTAG_ = { image_data_myriad_pro_small_0x6b,
    5, 9};//character: 'k' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x6c[5] __PRGMTAG_  = {
    0x01, 0x24, 0x92, 0x48, 0x00
};////character: 'l'

static const tImage myriad_pro_small_0x6c __PRGMTAG_ = { image_data_myriad_pro_small_0x6c,
    3, 5};//character: 'l' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x6d[15] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0xb1, 0x24, 0x92, 0x49, 0x24, 0x80, 0x00, 0x00, 0x00
};////character: 'm'

static const tImage myriad_pro_small_0x6d __PRGMTAG_ = { image_data_myriad_pro_small_0x6d,
    9, 15};//character: 'm' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x6e[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0xc4, 0x92, 0x49, 0x20, 0x00, 0x00
};////character: 'n'

static const tImage myriad_pro_small_0x6e __PRGMTAG_ = { image_data_myriad_pro_small_0x6e,
    6, 10};//character: 'n' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x6f[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0xe8, 0x61, 0x85, 0xe0, 0x00, 0x00
};////character: 'o'

static const tImage myriad_pro_small_0x6f __PRGMTAG_ = { image_data_myriad_pro_small_0x6f,
    6, 10};//character: 'o' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x70[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0xe4, 0x51, 0x45, 0xe4, 0x10, 0x00
};////character: 'p'

static const tImage myriad_pro_small_0x70 __PRGMTAG_ = { image_data_myriad_pro_small_0x70,
    6, 10};//character: 'p' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x71[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0xe8, 0xa2, 0x89, 0xe0, 0x82, 0x00
};////character: 'q'

static const tImage myriad_pro_small_0x71 __PRGMTAG_ = { image_data_myriad_pro_small_0x71,
    6, 10};//character: 'q' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x72[7] __PRGMTAG_  = {
    0x00, 0x00, 0x07, 0x44, 0x44, 0x00, 0x00
};////character: 'r'

static const tImage myriad_pro_small_0x72 __PRGMTAG_ = { image_data_myriad_pro_small_0x72,
    4, 7};//character: 'r' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x73[7] __PRGMTAG_  = {
    0x00, 0x00, 0x03, 0x42, 0x16, 0x00, 0x00
};////character: 's'

static const tImage myriad_pro_small_0x73 __PRGMTAG_ = { image_data_myriad_pro_small_0x73,
    4, 7};//character: 's' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x74[7] __PRGMTAG_  = {
    0x00, 0x00, 0x4e, 0x44, 0x42, 0x00, 0x00
};////character: 't'

static const tImage myriad_pro_small_0x74 __PRGMTAG_ = { image_data_myriad_pro_small_0x74,
    4, 7};//character: 't' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x75[10] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x01, 0x24, 0x92, 0x48, 0xe0, 0x00, 0x00
};////character: 'u'

static const tImage myriad_pro_small_0x75 __PRGMTAG_ = { image_data_myriad_pro_small_0x75,
    6, 10};//character: 'u' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x76[9] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x45, 0x4a, 0x51, 0x00, 0x00, 0x00
};////character: 'v'

static const tImage myriad_pro_small_0x76 __PRGMTAG_ = { image_data_myriad_pro_small_0x76,
    5, 9};//character: 'v' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x77[13] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x89, 0x5a, 0x5a, 0x66, 0x24, 0x00, 0x00, 0x00
};////character: 'w'

static const tImage myriad_pro_small_0x77 __PRGMTAG_ = { image_data_myriad_pro_small_0x77,
    8, 13};//character: 'w' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x78[9] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x65, 0x44, 0x54, 0x40, 0x00, 0x00
};////character: 'x'

static const tImage myriad_pro_small_0x78 __PRGMTAG_ = { image_data_myriad_pro_small_0x78,
    5, 9};//character: 'x' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x79[9] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x45, 0x4a, 0x51, 0x08, 0x88, 0x00
};////character: 'y'

static const tImage myriad_pro_small_0x79 __PRGMTAG_ = { image_data_myriad_pro_small_0x79,
    5, 9};//character: 'y' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x7a[9] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x78, 0x88, 0x47, 0x80, 0x00, 0x00
};////character: 'z'

static const tImage myriad_pro_small_0x7a __PRGMTAG_ = { image_data_myriad_pro_small_0x7a,
    5, 9};//character: 'z' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x7b[5] __PRGMTAG_  = {
    0x00, 0xa4, 0xa2, 0x49, 0x10
};////character: '{'

static const tImage myriad_pro_small_0x7b __PRGMTAG_ = { image_data_myriad_pro_small_0x7b,
    3, 5};//character: '{' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x7c[5] __PRGMTAG_  = {
    0x01, 0x24, 0x92, 0x49, 0x24
};////character: '|'

static const tImage myriad_pro_small_0x7c __PRGMTAG_ = { image_data_myriad_pro_small_0x7c,
    3, 5};//character: '|' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x7d[5] __PRGMTAG_  = {
    0x02, 0x24, 0x8a, 0x49, 0x40
};////character: '}'

static const tImage myriad_pro_small_0x7d __PRGMTAG_ = { image_data_myriad_pro_small_0x7d,
    3, 5};//character: '}' , height: 13, (charW,total bytes)

static const uint8_t image_data_myriad_pro_small_0x7e[12] __PRGMTAG_  = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x19, 0x4c, 0x00, 0x00, 0x00, 0x00, 0x00
};////character: '~'

static const tImage myriad_pro_small_0x7e __PRGMTAG_ = { image_data_myriad_pro_small_0x7e,
    7, 12};//character: '~' , height: 13, (charW,total bytes)


static const tChar myriad_pro_small_array[] = {

  // character: ' '
  {0x20, &myriad_pro_small_0x20},
  // character: '!'
  {0x21, &myriad_pro_small_0x21},
  // character: '"'
  {0x22, &myriad_pro_small_0x22},
  // character: '#'
  {0x23, &myriad_pro_small_0x23},
  // character: '$'
  {0x24, &myriad_pro_small_0x24},
  // character: '%'
  {0x25, &myriad_pro_small_0x25},
  // character: '&'
  {0x26, &myriad_pro_small_0x26},
  // character: '''
  {0x27, &myriad_pro_small_0x27},
  // character: '('
  {0x28, &myriad_pro_small_0x28},
  // character: ')'
  {0x29, &myriad_pro_small_0x29},
  // character: '*'
  {0x2a, &myriad_pro_small_0x2a},
  // character: '+'
  {0x2b, &myriad_pro_small_0x2b},
  // character: ','
  {0x2c, &myriad_pro_small_0x2c},
  // character: '-'
  {0x2d, &myriad_pro_small_0x2d},
  // character: '.'
  {0x2e, &myriad_pro_small_0x2e},
  // character: '/'
  {0x2f, &myriad_pro_small_0x2f},
  // character: '0'
  {0x30, &myriad_pro_small_0x30},
  // character: '1'
  {0x31, &myriad_pro_small_0x31},
  // character: '2'
  {0x32, &myriad_pro_small_0x32},
  // character: '3'
  {0x33, &myriad_pro_small_0x33},
  // character: '4'
  {0x34, &myriad_pro_small_0x34},
  // character: '5'
  {0x35, &myriad_pro_small_0x35},
  // character: '6'
  {0x36, &myriad_pro_small_0x36},
  // character: '7'
  {0x37, &myriad_pro_small_0x37},
  // character: '8'
  {0x38, &myriad_pro_small_0x38},
  // character: '9'
  {0x39, &myriad_pro_small_0x39},
  // character: ':'
  {0x3a, &myriad_pro_small_0x3a},
  // character: ';'
  {0x3b, &myriad_pro_small_0x3b},
  // character: '<'
  {0x3c, &myriad_pro_small_0x3c},
  // character: '='
  {0x3d, &myriad_pro_small_0x3d},
  // character: '>'
  {0x3e, &myriad_pro_small_0x3e},
  // character: '?'
  {0x3f, &myriad_pro_small_0x3f},
  // character: '\x0040'
  {0x40, &myriad_pro_small_0x40},
  // character: 'A'
  {0x41, &myriad_pro_small_0x41},
  // character: 'B'
  {0x42, &myriad_pro_small_0x42},
  // character: 'C'
  {0x43, &myriad_pro_small_0x43},
  // character: 'D'
  {0x44, &myriad_pro_small_0x44},
  // character: 'E'
  {0x45, &myriad_pro_small_0x45},
  // character: 'F'
  {0x46, &myriad_pro_small_0x46},
  // character: 'G'
  {0x47, &myriad_pro_small_0x47},
  // character: 'H'
  {0x48, &myriad_pro_small_0x48},
  // character: 'I'
  {0x49, &myriad_pro_small_0x49},
  // character: 'J'
  {0x4a, &myriad_pro_small_0x4a},
  // character: 'K'
  {0x4b, &myriad_pro_small_0x4b},
  // character: 'L'
  {0x4c, &myriad_pro_small_0x4c},
  // character: 'M'
  {0x4d, &myriad_pro_small_0x4d},
  // character: 'N'
  {0x4e, &myriad_pro_small_0x4e},
  // character: 'O'
  {0x4f, &myriad_pro_small_0x4f},
  // character: 'P'
  {0x50, &myriad_pro_small_0x50},
  // character: 'Q'
  {0x51, &myriad_pro_small_0x51},
  // character: 'R'
  {0x52, &myriad_pro_small_0x52},
  // character: 'S'
  {0x53, &myriad_pro_small_0x53},
  // character: 'T'
  {0x54, &myriad_pro_small_0x54},
  // character: 'U'
  {0x55, &myriad_pro_small_0x55},
  // character: 'V'
  {0x56, &myriad_pro_small_0x56},
  // character: 'W'
  {0x57, &myriad_pro_small_0x57},
  // character: 'X'
  {0x58, &myriad_pro_small_0x58},
  // character: 'Y'
  {0x59, &myriad_pro_small_0x59},
  // character: 'Z'
  {0x5a, &myriad_pro_small_0x5a},
  // character: '['
  {0x5b, &myriad_pro_small_0x5b},
  // character: '\'
  {0x5c, &myriad_pro_small_0x5c},
  // character: ']'
  {0x5d, &myriad_pro_small_0x5d},
  // character: '^'
  {0x5e, &myriad_pro_small_0x5e},
  // character: '_'
  {0x5f, &myriad_pro_small_0x5f},
  // character: '`'
  {0x60, &myriad_pro_small_0x60},
  // character: 'a'
  {0x61, &myriad_pro_small_0x61},
  // character: 'b'
  {0x62, &myriad_pro_small_0x62},
  // character: 'c'
  {0x63, &myriad_pro_small_0x63},
  // character: 'd'
  {0x64, &myriad_pro_small_0x64},
  // character: 'e'
  {0x65, &myriad_pro_small_0x65},
  // character: 'f'
  {0x66, &myriad_pro_small_0x66},
  // character: 'g'
  {0x67, &myriad_pro_small_0x67},
  // character: 'h'
  {0x68, &myriad_pro_small_0x68},
  // character: 'i'
  {0x69, &myriad_pro_small_0x69},
  // character: 'j'
  {0x6a, &myriad_pro_small_0x6a},
  // character: 'k'
  {0x6b, &myriad_pro_small_0x6b},
  // character: 'l'
  {0x6c, &myriad_pro_small_0x6c},
  // character: 'm'
  {0x6d, &myriad_pro_small_0x6d},
  // character: 'n'
  {0x6e, &myriad_pro_small_0x6e},
  // character: 'o'
  {0x6f, &myriad_pro_small_0x6f},
  // character: 'p'
  {0x70, &myriad_pro_small_0x70},
  // character: 'q'
  {0x71, &myriad_pro_small_0x71},
  // character: 'r'
  {0x72, &myriad_pro_small_0x72},
  // character: 's'
  {0x73, &myriad_pro_small_0x73},
  // character: 't'
  {0x74, &myriad_pro_small_0x74},
  // character: 'u'
  {0x75, &myriad_pro_small_0x75},
  // character: 'v'
  {0x76, &myriad_pro_small_0x76},
  // character: 'w'
  {0x77, &myriad_pro_small_0x77},
  // character: 'x'
  {0x78, &myriad_pro_small_0x78},
  // character: 'y'
  {0x79, &myriad_pro_small_0x79},
  // character: 'z'
  {0x7a, &myriad_pro_small_0x7a},
  // character: '{'
  {0x7b, &myriad_pro_small_0x7b},
  // character: '|'
  {0x7c, &myriad_pro_small_0x7c},
  // character: '}'
  {0x7d, &myriad_pro_small_0x7d},
  // character: '~'
  {0x7e, &myriad_pro_small_0x7e}
};

//num chars, array, width, height, compression

const tFont myriad_pro_small = { 95, myriad_pro_small_array,0,13,0 };
