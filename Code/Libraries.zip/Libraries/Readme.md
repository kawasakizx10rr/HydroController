Please use these files when compiling version 5.0.5
