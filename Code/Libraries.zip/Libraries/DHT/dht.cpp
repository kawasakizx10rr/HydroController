//
//    FILE: dht22.cpp
// VERSION: 0.1.00
// PURPOSE: DHT22 Temperature & Humidity Sensor library for Arduino
//
// DATASHEET: 
//
// HISTORY:
// 0.1.0 by Rob Tillaart (01/04/2011)
// inspired by DHT11 library
//

#include "dht.h"

#define TIMEOUT 1000

/////////////////////////////////////////////////////
//
// PUBLIC
//

dht::dht(uint8_t a_pin) {
	m_pin = a_pin;
}

bool dht::begin(dhtModels a_dhtModel) {
	m_dhtModel = a_dhtModel;
	return read();
}

// return values:
//  0 : OK
// -1 : checksum error
// -2 : timeout
int dht::read() {
	if (m_dhtModel == DHT11) {
		return read11();
	}
	else { // if (m_dhtModel == DHT22) {
		return read22();
	}
}

// return values:
//  0 : OK
// -1 : checksum error
// -2 : timeout
int dht::read11()
{
	// READ VALUES
	if (!readData()) 
		return false;

	// CONVERT AND STORE
	humidity    = bits[0];  // bit[1] == 0;
	temperature = bits[2];  // bits[3] == 0;

	// TEST CHECKSUM
	uint8_t sum = bits[0] + bits[2]; // bits[1] && bits[3] both 0
	if (bits[4] != sum) 
		return false;

	return true;
}

// return values:
//  0 : OK
// -1 : checksum error
// -2 : timeout
int dht::read22()
{
	// READ VALUES
	if (!readData()) 
		return false;

	// CONVERT AND STORE
	humidity    = word(bits[0], bits[1]) * 0.1;

	int sign = 1;
	if (bits[2] & 0x80) // negative temperature
	{
		bits[2] = bits[2] & 0x7F;
		sign = -1;
	}
	temperature = sign * word(bits[2], bits[3]) * 0.1;


	// TEST CHECKSUM
	uint8_t sum = bits[0] + bits[1] + bits[2] + bits[3];
	if (bits[4] != sum) 
		return false;

	return true;
}

/////////////////////////////////////////////////////
//
// PRIVATE
//

// return values:
//  0 : OK
// -2 : timeout
int dht::readData()
{
	// INIT BUFFERVAR TO RECEIVE DATA
	uint8_t cnt = 7;
	uint8_t idx = 0;

	// EMPTY BUFFER
	for (int i=0; i< 5; i++) bits[i] = 0;

	// REQUEST SAMPLE
	pinMode(m_pin, OUTPUT);
	digitalWrite(m_pin, LOW);
	delay(20);
	digitalWrite(m_pin, HIGH);
	delayMicroseconds(40);
	pinMode(m_pin, INPUT);

	// GET ACKNOWLEDGE or TIMEOUT
	unsigned int loopCnt = TIMEOUT;
	while(digitalRead(m_pin) == LOW)
		if (loopCnt-- == 0) 
			return false;

	loopCnt = TIMEOUT;
	while(digitalRead(m_pin) == HIGH)
		if (loopCnt-- == 0) 
			return false;

	// READ THE OUTPUT - 40 BITS => 5 BYTES
	for (int i=0; i<40; i++)
	{
		loopCnt = TIMEOUT;
		while(digitalRead(m_pin) == LOW)
			if (loopCnt-- == 0) 
				return false;

		unsigned long t = micros();

		loopCnt = TIMEOUT;
		while(digitalRead(m_pin) == HIGH)
			if (loopCnt-- == 0) 
				return false;

		if ((micros() - t) > 40) bits[idx] |= (1 << cnt);
		if (cnt == 0)   // next byte?
		{
			cnt = 7;   
			idx++;      
		}
		else cnt--;
	}

	return true;
}
//
// END OF FILE
//
