// 
//    FILE: dht.h
// VERSION: 0.1.00
// PURPOSE: DHT Temperature & Humidity Sensor library for Arduino
//
//     URL: http://arduino.cc/playground/Main/DHTLib
//
// HISTORY:
// see dht.cpp file
// 

#ifndef dht_h
#define dht_h

#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

#define DHT_LIB_VERSION "0.1.00"
enum dhtModels {DHT11, DHT22};

class dht
{
public:
	dht(uint8_t a_pin);
	bool begin(dhtModels a_dhtModel);
	int read();
	int read11();
    int read22();
	double humidity;
	double temperature;

private:
	dhtModels m_dhtModel;
	uint8_t m_pin;
	uint8_t bits[5];  // buffer to receive data
	int readData();
};
#endif
//
// END OF FILE
//
